# Wake & Actions Plugin — Changelog

## [1.2.1] - 2026-11-22

Two answers of a wake are corrected, the hosts saved on the page are called saved hosts, and an empty page shows its first steps. From the executing pass on Jen 7.2.0-beta.5 (BH4, BH5, BH8) and the look over its pages (V31, V52 and addition 11 of that review). `requires_jen` (5.68.0) and `plugin_api` (3) are unchanged. No migration; routes, endpoint names, audit actions and the API's fields are unchanged.

### Fixed: on a host with no `ip` command every wake was told Jen has no address in the subnet (BH4)

Since 1.2.0 a wake asks Jen whether Jen's own host has an address in the subnet of the wake. Jen reads the host's addresses with the `ip` command and, when that cannot run, falls back to what the hostname resolves to. On Ubuntu that is `127.0.1.1`, which is in no subnet, so the answer came back "Jen has no address there" when the truth was "Jen could not tell". Jen's container image up to 7.2.0-beta.5 installs no `ip` command, so under host networking, the setup the README recommends for Wake, every wake got the warning *Jen has no address in that subnet, so it arrives only if a router forwards directed broadcasts* and its audit row said `on_link=no`, while the packet was on the LAN.

The plugin now looks for the `ip` command itself, in the same four places Jen does (`/usr/sbin/ip`, `/sbin/ip`, `/bin/ip`, and `ip` on the PATH), before it asks. When there is none the answer is "could not be asked": the plain sentence *Wake packet sent to ...*, `on_link` is `null` in the API answer and the audit row says `on_link=unknown`. With an `ip` command the three answers of 1.2.0 are as they were. The send itself was never affected.

One consequence to know: in an image with no `ip` command the plain sentence is now also what a wake gets on Docker's default bridge network, where 1.2.0's warning happened to be true (the packet does not reach the LAN from there). "Could not tell" is the honest answer in both cases; the warning needs an image or a host that has the `ip` command. The README's Docker section says what the container needs for a wake to arrive.

### Fixed: a wake on a subnet Jen is not configured for was answered as a success (BH5)

A wake goes to the directed broadcast of the MAC's subnet and to `255.255.255.255`. When the MAC is on a Kea subnet that is not in Jen's subnet list, Jen has no broadcast address for it and only `255.255.255.255` is targeted, which stays on the network Jen's host is on. 1.2.0 warned about that only when the MAC had no subnet at all; with a subnet id Jen does not know it answered *Wake packet sent to host.* as a success. It is now a warning: *Wake packet sent on Jen's own network only: subnet 7 is not one Jen is configured for.* Only an account that sees every subnet can reach this. The API answer already listed the one address in `targets` and is unchanged.

### Changed: the hosts saved on the page are "saved hosts" (V31)

Jen's own navigation has Favorites now (pinned pages), so one word meant two things. On the Wake page, in its messages and on the Investigation card the hosts you saved are *saved hosts*: the button is "Save Host", the column "Saved host", the messages "... added to saved hosts.", "Saved host removed.", "Saved host not found.", "That saved host is not yours to change.", "That saved host changed while you were saving it ...", "Could not save the host; the details are in Jen's log." and "Could not remove the saved host; the details are in Jen's log.", and the card's summary "A saved host (label)". The plugin's description under Settings, Plugins and the README follow. The column "SecureOn" is headed "SecureOn password".

Only the words a person reads changed. The routes (`/management/wol/favorites/...`), the endpoint and function names, the table `wol_hosts`, the audit actions `WOL_ADD_FAVORITE` and `WOL_DELETE_FAVORITE`, the audit detail `via=favorite` and the text of the audit rows are as they were, so a search of the Audit page finds the same rows as before.

### The audit names across the upgrade to 1.2.0 (BH8)

Audit rows written before 1.2.0 keep the action names they were written with (`WOL_ADD_FAVOURITE`, `WOL_DELETE_FAVOURITE`), so a search of the Audit page for `WOL_` finds both spellings and a search for `FAVORITE` finds only the rows written since 1.2.0.

### The page: first steps in place of an empty table, and the button stays in the header (V52, addition 11)

With no saved host the page showed an empty table with one line of text, which on a phone sat high in its row. It now shows a "Getting started" card in its place, with two steps: save a host (with the Save Host button in the step, or for a viewer the note that saving needs an admin, and the reminder that the Wake action on a Lease, Reservation or Device row needs no saved host), and what happens then: nothing is sent until someone presses Wake, and Jen then sends the packet to the broadcast address of the host's subnet and to its own network, writes the wake to the audit log and shows when the host was last woken and by whom. Wake registers no alert type, so there is no third step.

At tablet width the header's long sentence pushed the button under it. The sentence is shorter and now wraps before the button moves, so Save Host stays at the right of the header down to phone width.

### The harness

`tools/test_plugin.py` runs the real `_ip_command_present` with the three paths and the PATH lookup stood in, and the real wake routes with it answering False: the plain sentence, `on_link=unknown`, and the context is not asked (1.2.0: the warning and `on_link=no`). It checks the new answer of `sent_message` for a subnet id with no broadcast, through the pure function and through the row action and the API, and that the three answers of 1.2.0 are unchanged. It reads the template, every flash sentence, the refusals, the Investigation card, the manifest and the README for the word favorite, which is left only in the endpoint names and inside code, and checks the page's first steps, headings and buttons. The on-link checks of 1.2.0 now stand `_ip_command_present` in as True, so they do not depend on the box they run on.

## [1.2.0] - 2026-11-21

A wake now says when it left Jen's own network, the audit row of a wake names who asked and how, a wake is refused when the saved settings cannot be read, and the plugin is spelled the American way throughout. Four rows of the 7.2.0 plugin audit (WOL-1 to WOL-4) and the spelling pass Jen's own suite was waiting for (WOL-16), with the README sentence of WOL-22. `requires_jen` stays 5.68.0 (`subnet_context` has been in `jen.plugin_api` since 5.30.0) and `plugin_api` stays 3. No migration; no stored data changes. This is a MINOR release because three route paths and two audit codes are renamed and the API answer gains two fields.

### Fixed: "Wake packet sent" when the packet could not arrive (WOL-1, WOL-2)

A wake is sent to the target subnet's directed broadcast address and to `255.255.255.255`. When Jen's host has an address in that subnet, either one reaches the host. When it does not (a routed VLAN whose clients reach Kea through a relay, or any subnet at all when Jen runs in a container on Docker's default bridge network), the limited broadcast stays on the network Jen is on and the directed broadcast is handed to a router, which drops it unless it was configured to forward directed broadcasts. The send itself succeeds in every one of these cases, so the page said *Wake packet sent to X.*, the API answered `{"ok": true}`, and nothing woke. The limitation was written in the README and nowhere a person looks at the moment of the wake.

The send is unchanged: the same two addresses as before. What changed is the answer. Once per wake, after the packet has gone, the plugin asks Jen's `subnet_context` whether Jen has an address in the subnet of the wake, and keeps three answers apart:

- Jen has an address there: the sentence used before, unchanged.
- Jen answered and has none: a warning, *Wake packet sent toward 10.0.2.255 for aa:bb:cc:dd:ee:ff. Jen has no address in that subnet, so it arrives only if a router forwards directed broadcasts.*
- Jen could not be asked (the context raised, or answered nothing for that subnet): the sentence used before. Not knowing is not a reason to alarm, and the exception goes to Jen's log, never to the page.

A MAC Jen has no subnet for (only an account that sees every subnet may wake one) is its own case, since only the limited broadcast is targeted: *Wake packet sent on Jen's own network only: Jen does not know which subnet aa:bb:cc:dd:ee:ff is on.*, also a warning.

The API answer on success keeps `ok` and `mac` and gains `on_link` (`true`, `false` or `null`) and `targets`, the addresses the packet was sent to, sorted as text. The README has a new section, "When the host is on another subnet or Jen runs in Docker", which says what a router has to do and that under Docker the container needs host networking or a macvlan network.

### Fixed: the audit row of a wake through the API named nobody (WOL-3)

`WOL_SENT` recorded `subnet_id=N` and nothing else. For a wake from a page the audit row at least carried the signed-in user. A request with an API key has no session user, so its row read `system` and the key's name was nowhere in it. The detail is now `via=<favorite|row|page|api> subnet_id=<N or none> on_link=<yes|no|unknown>`: which entry point the wake came through, the subnet it was sent on, and the on-link answer above. A wake through the API starts with `[api-key:<name>]`, exactly the prefix Jen's own API writes use, so one search of the Audit page finds everything a key did. The Wake button of the favorites list is recorded as `via=favorite` and the Wake row action as `via=row`; `page` is the value for a wake that names no entry point of its own, and no route of this release sends one.

### Fixed: a wake went out without the SecureOn password when the favorite could not be read (WOL-4)

Before sending, a wake looks up the MAC's favorite, because the favorite may hold a SecureOn password. If that lookup failed (the database did not answer), the wake went on as if there were no favorite. For a NIC that requires SecureOn the packet was then built without the password, the NIC ignored it, and the person was told *Wake packet sent*; the wake was audited as sent and the 5-second limit was started. "The lookup failed" was read as "there is no favorite", which are different answers.

A lookup that fails now refuses the wake, for every caller whatever they may see: nothing is sent, nothing is audited as sent, the rate limit is not started, and the exception is logged. The page and the row action say *Could not read the saved wake settings - nothing was sent. Try again in a moment.* The API answers 503 with `{"ok": false, "error": "The saved wake settings could not be read"}`. The Wake button of the favorites list reads its favorite by id and used to answer a failed read with an error page; it now gives the same sentence. A lookup that answered "no favorite" is unchanged: the wake goes without a password, as it should.

### Changed: American spelling everywhere, including three route paths and two audit codes (WOL-16)

Jen's own pages and manual say "favorite"; this plugin said "favourite" in its page heading, buttons, every flash, the Investigation card, its description under Settings, Plugins, and its README. All of it is now "favorite", and so are the names behind it:

- The form actions `/management/wol/favourites/add`, `/management/wol/favourites/<id>/delete` and `/management/wol/favourites/<id>/wake` are now `/management/wol/favorites/...`. They are renamed outright, with no alias: they are POST form actions the page itself fills in, and nothing bookmarks them.
- **The audit codes `WOL_ADD_FAVOURITE` and `WOL_DELETE_FAVOURITE` are now `WOL_ADD_FAVORITE` and `WOL_DELETE_FAVORITE`.** Rows written before the upgrade keep the old code on the Audit page; a filter for the history of the favorites list has to name both.
- Function, endpoint and template names follow (`add_favorite`, `delete_favorite`, `wake_favorite`, and so on), and comments say `normalization`, `authorized` and `judgment`.

Database table and column names are not changed, and the entries below this one are a record and keep the spelling they were written in.

### Documentation (WOL-22)

The README said the subnet of a wake is found from the MAC's "active lease, then its reservation". The plugin has used Jen's own precedence since 1.0.2, which adds the device's last known subnet, the case that matters most for a host that is asleep. The sentence now says so. The module docstring no longer calls the SecureOn password "not a real secret"; it has been stored encrypted since 1.0.2.

### Harness

The fake socket now records where each packet was sent, and a check runs the real `_send_wake` and names the two addresses; before, a change that dropped the directed broadcast would have passed. New checks run the real routes for each on-link answer (the sentence, its category, the API fields), for `subnet_context` raising, for the `WOL_SENT` detail of each entry point with a key named `backup-box`, and for a favorite lookup that raises (no send, no audit row, the refusal, 503, and the next wake not rate limited). The stub Blueprint records every route it is given, so the renamed paths are checked as registered and the old ones as gone.

## [1.1.7] - 2026-10-12

Cleanup; no change to what a wake does or to any stored data. `requires_jen` (5.68.0) and `plugin_api` (3) are unchanged: the helpers this release imports (`require_write`, `is_admin_or_above`) have been in `jen.plugin_api` since 5.65.10.

### Changed: the admin check and the viewer gate are Jen's, not a copy

Each plugin carried its own `_is_admin` and `_require_write`, with a fallback to reading `current_user.role` for a Jen that did not export the helper; copies of that shape had drifted between plugins. The four write routes (add, delete, wake from the list, and the Wake row action) now use `jen.plugin_api.require_write` with this plugin's sentence and the Wake page as the place to land, and the page asks `is_admin_or_above()` directly. For a form post nothing a person sees changes: the same sentence, the same redirect, decided before the route reads the request. A request that is JSON or under `/api/` would now get a 403 body instead of a flash that surfaces on the next page; none of this plugin's session routes is one (its one JSON route is key-authenticated and never flashes), so this is a guard, not a change.

### Added: Investigate on every favourite row

A favourite row names a host, so it carries Jen's Investigate action (the shared `investigate_link` macro), given the favourite's MAC.

### Fixed: the Add Favourite form no longer promises the IP is shown on the row

The IP field said it was "shown on the row". It never is: the address is stored with the favourite and nothing reads it back (a wake goes by the MAC and the subnet's broadcast address). The hint now says it is kept with the favourite, and the README says the column is recorded and not displayed. The column is not dropped.

### Documented, not changed

`_derive_subnet_id` stays: it takes the subnet map as an argument so the harness can run it on a fixed map, where `plugin_api.subnet_for_ip` reads Jen's live one. `in_scope`, `_when` and `subnet_label` stay: they are pure functions of this plugin's own cards, and `plugin_api` has no equivalent. `_normalize_mac` stays as a thin wrapper because this plugin treats a bad MAC as "none given" (`""`), where `plugin_api.normalize_mac` answers `None`.

## [1.1.6] - 2026-10-11

Fix. No change to what Jen needs: `requires_jen` stays 5.68.0.

### Fixed: saving a favourite has one refusal, whether the favourite exists or not

1.1.5 stopped telling a caller that a favourite they could not see was "not on a subnet you can access", and said instead that the favourite
was not theirs. It left a second sentence for the other way a save is refused: a MAC with no favourite at all, in a subnet the caller cannot see.
Two sentences for one refusal is a question the caller can ask: save over a MAC and read which sentence comes back, and you know whether
somebody else already has a favourite for it. `_save_favourite` now returns *That favourite is not yours to change.* in both cases, and writes and
audits nothing in either. Waking a host probes no stored object, so a wake of a MAC the caller cannot see keeps *That MAC is not on a subnet
you can access.*, which is true there.

The harness runs the two refusals through the real function against its fake database and requires the same answer from both.

## [1.1.5] - 2026-10-11

Fix. No change to what Jen needs: `requires_jen` stays 5.68.0.

### Fixed: a wake no longer stamps a favourite the caller may not see

Waking a host stamped `last_woken_at` and `last_woken_by` on the host's favourite, whoever owned it. The wake itself is judged on where the
host is now, and a favourite is judged on the subnet it was stored in, so an admin of subnet A could wake a host in A whose favourite was
stored in subnet B: the packet went out correctly, and the B favourite's row was then rewritten with the A admin's username. A row the caller
could not see was changed, and its owner was shown who woke the host. `wake_inputs` now also returns whether a favourite exists and the caller
may see it, and `_wake_mac` writes the stamp only on that answer (the default writes nothing). The wake, the SecureOn password rule and the
audit and event are unchanged; the page, the row action and the JSON API all go through the same two functions.

### Fixed: the refusal for a favourite that is not yours no longer talks about the MAC

Saving a favourite over one the caller may not see (including losing the insert race to one) answered *That MAC is not on a subnet you can
access*, a false sentence for a MAC the caller can see and a way to learn that a hidden favourite exists. It now says exactly *That favourite
is not yours to change.* and nothing about the MAC. A MAC with no favourite that is in no subnet the caller can see keeps its own sentence, which
is true there, and so does a wake of such a MAC.

The harness runs the real routes against its fake database: a favourite saved in another subnet is not stamped by a wake from the page's row
action or by a scoped API key, one in the caller's own subnet is (with the caller's name, or `api:<key>`), a host with no favourite writes
nothing, and the refusal sentences are pinned.

## [1.1.4] - 2026-10-07

Fix. No change to what Jen needs: `requires_jen` stays 5.68.0.

### Fixed: judging a favourite and writing it are one transaction

*Add favourite* read the existing row on one connection, closed it, judged the owner, and then wrote on another with
`INSERT ... ON DUPLICATE KEY UPDATE`. A favourite another admin created or changed in the moment between the two was rewritten by the
second statement: its label, address and SecureOn password, whatever subnet it was stored in. The route now does both on one connection:
the row is read `FOR UPDATE` (so nobody else can change or create it until the request ends), judged on its own stored subnet, and updated
with that owner as a predicate (`WHERE mac=... AND subnet_id <=> owner`); the count is checked, and a row that is no longer the one that was
judged refuses with *That favourite changed while you were saving it — nothing was changed* and audits nothing. A new favourite is a plain
`INSERT`: if another request created it first (duplicate key, or a deadlock between two inserts of one MAC) the row that won is locked and
judged again, and one in a subnet the caller cannot see is refused, never updated. *Delete* gets the same discipline (read `FOR UPDATE`,
delete under the judged owner, count checked). The harness interleaves a hidden-subnet row between the judgement and the write for
add, the lost-race insert, the deadlock and delete.

## [1.1.3] - 2026-10-07

Fix. No change to what Jen needs: `requires_jen` stays 5.68.0.

### Fixed: a failed existence lookup is no longer read as "no such favourite"

*Add favourite* starts by looking up whether the MAC already has a favourite, and the answer decides who may touch it. That lookup
treated a SELECT that raised the same as "no favourite", so with the database failing for that one statement the route carried on as
if the MAC were new, judged it on the client's current subnet, and its `INSERT ... ON DUPLICATE KEY UPDATE` rewrote the label, address
and SecureOn password of a favourite stored in a subnet the caller cannot see. The lookup now has three outcomes (found, not found,
failed): on a failure the route flashes *Could not check the existing record — nothing was changed*, logs, writes nothing and audits
nothing. The other statements in the plugin that read before they write were checked: delete and the wake from the list fail as a
whole (nothing is written), and a failed read of the favourite for a wake means the wake goes ahead without its password.

## [1.1.2] - 2026-10-06

Fix: the rule 1.1.1 applied to the Investigation card now applies to every surface of the plugin. No change to what Jen needs:
`requires_jen` stays 5.68.0.

### Fixed: a favourite is judged by its stored subnet on the page, in add and delete, and in the wake

1.1.1 stopped the Investigation card from judging a favourite by where its MAC is now, and left the rest of the plugin as it
was. The favourites list, "Add favourite" over an existing MAC, delete, and the wake from a favourite all still judged the row
on the MAC's current subnet with the stored one as a fallback, so a favourite saved in subnet B (its label, whether a SecureOn
password is set) listed for a caller scoped to A once the client moved to A, and that caller could rewrite its label, address
and SecureOn password or delete it. A favourite is a stored object and is now judged on its own stored subnet everywhere; a
favourite with no subnet is for an unrestricted caller only. Where the host is now appears on the list as *now in …* only when
the caller may see that subnet.

### Fixed: a wake never borrows a favourite's SecureOn password the caller may not see

A wake is an act on a live host and is still judged on where the host is now — that is the network the packet is sent to. But
the wake from a row (the *Wake* row action) and the wake API read the stored favourite's SecureOn password first and judged the
subnet afterwards, so a caller scoped to A waking a host now in A used a hidden favourite's password stored in B, and an API key
did the same. The password is now read for a wake only when the favourite's own stored subnet is in the caller's scope (the
session's, or the key's for the API); a favourite out of scope contributes nothing to the wake, neither its password nor its
stored subnet as a fallback, so the wake goes ahead without it and a NIC that wants the password ignores the packet. Waking from
the favourites list needs both: the favourite in scope by its stored subnet, and the host's current subnet in scope.

## [1.1.1] - 2026-10-06

Fix to the investigation provider added in 1.1.0. No change to what Jen needs: `requires_jen` stays 5.68.0.

### Fixed: a favourite is judged by the subnet it was saved in, not by where the client is now

1.1.0 judged the Investigation card by the subnet the MAC is in now, falling back to the favourite's own. That is the right
question for a wake, which acts on a live host, and the wrong one for showing stored data: a favourite saved in subnet B
(its label, whether a SecureOn password is set, who last woke it) was shown to a caller scoped to subnet A as soon as the
client's lease moved to A. A favourite is now judged by its own stored subnet, and a favourite with no subnet is for an
unrestricted caller only. Where the client is now is shown on the card as **Now in** when the caller may see that subnet —
only ever as a fact, and never named when it is a subnet the caller cannot see. The wake itself is unchanged.

## [1.1.0] - 2026-10-04

Requires Jen 5.68.0 (a 5.68.0 beta satisfies it): this release registers an **investigation provider**.

### Added: favourite, SecureOn and last wake, on Jen's Investigation page

Jen's Investigation page (`/client`) now has a "What else Jen knows" section on its Overview, and this plugin
contributes one card to it for a client that is a saved favourite: its label, whether a SecureOn password is set (never
the password), and when and by whom it was last woken. A client that was never saved here adds no card.

The card is judged the way a wake of the same MAC is: on the subnet the MAC is in now (Jen's one precedence), falling
back to the subnet stored on its favourite, and a client outside the caller's scope — or in no subnet, for a restricted
caller — gets nothing. `requires_jen` moves to 5.68.0 because the hook does not exist before it.

## [1.0.4] - 2026-09-27

Follow-up to 1.0.3, found while Jen's own authorization matrix added a row for a malformed API
body on every plugin API route.

### Fixed: a malformed JSON body crashed the wake API instead of refusing it

`_api_wake` read its body as `request.get_json(silent=True) or {}` — the `or {}` only rescues a
falsy body (`None`, an empty object), so a JSON array or any other non-object value reached
`body.get("mac", "")` directly and raised `AttributeError`, an unhandled 500. It now goes through
Jen's shared `json_object_body()`/`str_field()` (the same helpers every other plugin API route
already uses), which refuse a malformed body with a real `400 {"error": "expected a JSON object"}`
before touching it. A non-string `mac` (`{"mac": 5}`) is unaffected — it was, and still is, a
caller-visible "invalid mac".

### Changed

- `tools/test_plugin.py` sends a JSON array to `_api_wake` and checks it gets 400, not an
  uncaught exception.

## [1.0.3] - 2026-09-27

Jen's Q100 sweep: the favourites list, adding one, deleting one and waking one judged access on the
STORED subnet a favourite was created with, which nothing ever refreshed — the same shape of bug
Presence 1.0.2 fixed for tracked devices. `wake_from_row` and the JSON API already judged the MAC's
CURRENT subnet correctly; the favourites themselves did not.

### Fixed: a moved favourite stayed visible, and wakeable, to the wrong administrator

A favourite is added once and its subnet stored then. If the device later moves — a new lease in a
different subnet, a changed reservation — the favourites list, deleting a favourite and waking one all
still judged access on that stale stored value. An administrator scoped to subnet A who had favourited a
laptop still saw it, and could wake it, after it moved to subnet B; an administrator newly responsible for
subnet B would not see it at all. Every one of the three now judges the MAC's subnet as it is right now
(Jen's one precedence: a current lease, then a reservation, then the device's last known subnet), falling
back to the stored value only when the MAC has none currently — the list's display and the packet's
target broadcast domain move with it too.

### Fixed: re-adding an existing favourite could silently reassign it

"Add Favourite" for a MAC that already had one judged access on the MAC's current subnet and then
overwrote the existing row's subnet, address and label. An administrator who could see where the MAC is
now could take over — and relocate — a favourite an administrator for a different subnet had created,
without ever being checked against the row they were about to change. The existing row, when there is
one, is now authorised on its own subject first (current subnet, its own stored value as the fallback),
and this route never moves a favourite's subnet.

### Fixed: two smaller findings from the same audit

- The JSON API mapped a stored SecureOn password that could not be decrypted — a clear, caller-visible
  refusal ("enter it again") — to a 500, the same as an actual server fault. It is `409` now.
- `_wake_subject` (behind `wake_from_row` and the JSON API) had no exception handling around its
  database read at all; a failure there used to propagate into an uncaught error. It now degrades to
  judging the wake on the MAC's current subnet alone and logs the failure, rather than crashing.

### Changed

- The MAC check delegates to Jen's shared `normalize_mac()`.
- `tools/test_plugin.py` checks a favourite that moved into and out of the caller's subnet directly, that
  re-adding an existing favourite never changes its stored subnet, and the new 409 mapping.

## [1.0.2] - 2026-09-25

Requires Jen 5.65.6 or later (`client_subnet_for_mac` in the plugin API). Adds one migration (the `secureon` column becomes `TEXT` so it can hold the encrypted form); it runs by itself on the next start.

### Fixed: the SecureOn password was stored in clear

Every other plugin credential is stored with Jen's `encrypt_secret`; a favourite's SecureOn password was inserted exactly as typed. It is now encrypted on write, and never shown again (the page has only ever shown whether one is set). A favourite saved by 1.0.0 or 1.0.1 still wakes: a stored value that is not in Jen's encrypted format is accepted as the legacy plain value it is, and is re-encrypted in place the first time it is used. A stored value that cannot be decrypted (a restored database with a different key) refuses the wake with a plain message instead of sending a packet without the password.

### Changed: one place decides which subnet a MAC is in

The plugin carried its own lookup (a lease, then a reservation); Jen now offers one precedence to every plugin, `client_subnet_for_mac` (current lease, then reservation, then the device's last known subnet), and this plugin uses it. The device fallback means a MAC Jen only knows from its devices table now has a subnet to be judged on.

### Fixed: raw exception text on the page

A failed send, add, or remove put the exception's own text into the page. The details go to Jen's log and the page shows a generic message.

### Changed

- `tools/test_plugin.py` covers the SecureOn round trip, the legacy read and re-encrypt, an undecryptable value, and the failed-send message.

## [1.0.1] - 2026-09-25

Requires Jen 5.65.2 or later (the `can_access_subnet` and `api_key_can_access_subnet` helpers in the plugin API).

### Fixed: routes authorised one thing and acted on another

The wake packet always also goes out on the limited broadcast (`255.255.255.255`) to the Jen host's own segment, so the subnet check was the only thing standing between a subnet-restricted admin and waking any host on that segment. Four places got it wrong. The pattern this release names in every plugin: a route authorises on one thing (a subnet id the caller typed, or nothing for a by-id POST) and acts on another, or reads "no subnet" as "allow".

- **"Wake" from a lease, reservation or device row** authorised the `subnet_id` in the query string, which is only what the row that linked there happened to know. A caller could name a subnet they own and wake a MAC in another. The value is now ignored; the subnet is the one the MAC is in (its active lease, then its reservation, then, for a MAC with neither, the subnet stored on its favourite).
- **Adding a favourite** worked the subnet out from the optional IP field, so any MAC could be attached to a subnet the caller owns. The subnet now comes from the MAC; a typed address that is not in it is not stored. A MAC Jen has never seen has no subnet and is for accounts that can see every subnet.
- **Removing a favourite** by id checked nothing about the row; it now reads as not found unless the row's subnet is the caller's (a favourite with no subnet is an unrestricted account's).
- **The wake API** let a MAC with no attributable subnet through to a subnet-scoped key. That is now for unrestricted keys only.

### Fixed: re-adding a favourite with a blank SecureOn erased the saved password

The upsert wrote the blank over the stored value. A blank field now keeps what is saved (the form says so).

### Fixed: the rate-limit map grew for as long as Jen ran

Every distinct MAC ever woken stayed in the once-per-five-seconds map forever. Each wake now drops entries older than a minute.

### Corrected: the version floor

1.0.0's README and changelog said Jen 5.61.0 while its manifest said 5.57.0; 5.57.0 was the true floor for 1.0.0, which used only the row-action and plugin-API v3 surfaces that existed then. 1.0.1 uses the subnet helpers added in Jen 5.65.2, so all three now say 5.65.2.

### Changed

- The row action link no longer carries `ip` and `subnet_id` (the route ignores both).
- The page's static styling moved out of inline `style=` attributes into its own `<style>` block; `tools/verify.py` now fails a template that carries one.
- `tools/test_plugin.py` now runs the real routes and the API against fakes: a MAC in another subnet is not woken whatever the query string says, a blank SecureOn keeps the stored one, and the rate map is pruned.

## [1.0.0] - 2026-09-24

*Correction, 2026-09-25: the last paragraph below says this release was built on Jen 5.61.0's plugin API; the floor it actually needed, and declared in its manifest, was Jen 5.57.0.*

### First release

Wake-on-LAN from any Lease, Reservation, or Device row, plus a
favourites list for the hosts you wake often — the first plugin
built on Jen's row actions. A single click sends a standard 102-byte
magic packet (with an optional SecureOn password) over broadcast UDP
to both the target subnet's directed broadcast address and
`255.255.255.255`, so a target on the same L2 as Jen wakes reliably
without any extra router configuration.

Every wake is rate-limited to once per MAC every five seconds,
audited, and raises a `plugin.wol.sent` event. Favourites remember a
label, an optional SecureOn password, and when they were last woken
and by whom; a small JSON API lets another tool send a wake with a
Jen API key. Everything respects Jen's subnet access control — a
favourite on a subnet you can't see is neither shown nor wakeable.

Built on Jen 5.61.0's plugin API v3 from the first commit: sprite
icons, a phone-ready rowlist, and no inline styles.
